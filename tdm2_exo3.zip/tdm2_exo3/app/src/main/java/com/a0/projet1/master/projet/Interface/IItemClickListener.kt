package com.a0.projet1.master.projet.Interface

import android.view.View

interface IItemClickListener {
    fun onclick(view: View, position:Int )
}