package com.a0.projet1.master.projet.Model

import android.net.Uri
import java.util.*

class Intervention (var num: Int? =null,
               var nom:String?=null,
               var type:String?=null,
               var date_depot: String? =null
){
    // var date:String?=null
}